#include "Utils.h"
#include <algorithm>
#include <cctype>
#include <chrono>
#include <random>
#include <sstream>

namespace util {

std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(s[b-1]))) --b;
    return s.substr(a, b - a);
}

std::string toLower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(),
                   [](unsigned char c){ return std::tolower(c); });
    return r;
}

// Remove bytes that enable command/SQL injection or break our storage format,
// plus control characters. Keeps letters, digits, spaces and common name punct.
std::string sanitize(const std::string& raw, size_t maxLen) {
    std::string in = trim(raw);
    if (in.size() > maxLen) in = in.substr(0, maxLen);
    static const std::string banned = ";|&$`<>\\\"'\r\n\t";
    std::string out;
    out.reserve(in.size());
    for (unsigned char c : in) {
        if (c < 0x20) continue;                 // strip control chars
        if (banned.find(static_cast<char>(c)) != std::string::npos) continue;
        out += static_cast<char>(c);
    }
    return out;
}

std::string htmlEscape(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        switch (c) {
            case '&':  out += "&amp;";  break;
            case '<':  out += "&lt;";   break;
            case '>':  out += "&gt;";   break;
            case '"':  out += "&quot;"; break;
            case '\'': out += "&#39;";  break;
            default:   out += c;
        }
    }
    return out;
}

bool isValidEmail(const std::string& s) {
    auto at = s.find('@');
    if (at == std::string::npos || at == 0) return false;
    auto dot = s.find('.', at);
    if (dot == std::string::npos || dot + 1 >= s.size()) return false;
    if (s.find(' ') != std::string::npos) return false;
    return s.size() <= 254;
}

bool isStrongPassword(const std::string& s) {
    if (s.size() < 8) return false;
    bool up=false, lo=false, dig=false, sym=false;
    for (unsigned char c : s) {
        if (std::isupper(c)) up = true;
        else if (std::islower(c)) lo = true;
        else if (std::isdigit(c)) dig = true;
        else sym = true;
    }
    return up && lo && dig && sym;
}

bool isValidNim(const std::string& s) {
    if (s.size() < 8 || s.size() > 15) return false;
    return std::all_of(s.begin(), s.end(),
                       [](unsigned char c){ return std::isdigit(c); });
}

std::string csvEscape(const std::string& field) {
    bool needQuote = field.find_first_of(",\"\n\r") != std::string::npos;
    if (!needQuote) return field;
    std::string out = "\"";
    for (char c : field) { if (c == '"') out += '"'; out += c; }
    out += "\"";
    return out;
}

std::vector<std::string> csvSplit(const std::string& line) {
    std::vector<std::string> fields;
    std::string cur;
    bool inQuotes = false;
    for (size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (inQuotes) {
            if (c == '"') {
                if (i + 1 < line.size() && line[i+1] == '"') { cur += '"'; ++i; }
                else inQuotes = false;
            } else cur += c;
        } else {
            if (c == '"') inQuotes = true;
            else if (c == ',') { fields.push_back(cur); cur.clear(); }
            else if (c == '\r') { /* skip */ }
            else cur += c;
        }
    }
    fields.push_back(cur);
    return fields;
}

std::string jsonEscape(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (unsigned char c : s) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n";  break;
            case '\r': out += "\\r";  break;
            case '\t': out += "\\t";  break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else out += static_cast<char>(c);
        }
    }
    return out;
}

static std::mt19937_64& rng() {
    // Seed from the high-resolution clock + random_device for unpredictability.
    static std::mt19937_64 gen([]{
        std::random_device rd;
        auto t = std::chrono::high_resolution_clock::now().time_since_epoch().count();
        return static_cast<uint64_t>(rd()) ^ static_cast<uint64_t>(t);
    }());
    return gen;
}

std::string randomDigits(int n) {
    std::uniform_int_distribution<int> d(0, 9);
    std::string s;
    s.reserve(n);
    for (int i = 0; i < n; ++i) s += char('0' + d(rng()));
    return s;
}

std::string randomHex(int nBytes) {
    static const char* hex = "0123456789abcdef";
    std::uniform_int_distribution<int> d(0, 255);
    std::string s;
    s.reserve(nBytes * 2);
    for (int i = 0; i < nBytes; ++i) {
        int b = d(rng());
        s += hex[(b >> 4) & 0xf];
        s += hex[b & 0xf];
    }
    return s;
}

long long nowSeconds() {
    return std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
}

} // namespace util
