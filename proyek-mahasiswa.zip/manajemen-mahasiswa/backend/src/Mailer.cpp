#include "Mailer.h"
#include "Utils.h"
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <vector>

#ifdef HAVE_CURL
#include <curl/curl.h>
#endif

namespace {

std::string env(const char* key) {
    const char* v = std::getenv(key);
    return v ? std::string(v) : std::string();
}

void devPrint(const std::string& to, const std::string& code) {
    std::cout << "\n";
    std::cout << "================ OTP (DEV MODE) ================\n";
    std::cout << "  To   : " << to   << "\n";
    std::cout << "  Code : " << code << "  (valid 60 detik)\n";
    std::cout << "  (Set SMTP_URL/SMTP_USER/SMTP_PASS untuk kirim email asli)\n";
    std::cout << "===============================================\n\n";
    std::cout.flush();
}

#ifdef HAVE_CURL
struct UploadCtx { std::string payload; size_t pos = 0; };

size_t readCb(void* ptr, size_t size, size_t nmemb, void* userp) {
    auto* ctx = static_cast<UploadCtx*>(userp);
    size_t room = size * nmemb;
    if (ctx->pos >= ctx->payload.size() || room == 0) return 0;
    size_t n = std::min(room, ctx->payload.size() - ctx->pos);
    std::memcpy(ptr, ctx->payload.data() + ctx->pos, n);
    ctx->pos += n;
    return n;
}

bool sendViaCurl(const std::string& to, const std::string& toName,
                 const std::string& code) {
    std::string url  = env("SMTP_URL");
    std::string user = env("SMTP_USER");
    std::string pass = env("SMTP_PASS");
    std::string from = env("SMTP_FROM"); if (from.empty()) from = user;
    if (url.empty() || user.empty()) return false;

    CURL* curl = curl_easy_init();
    if (!curl) return false;

    std::ostringstream body;
    body << "To: " << to << "\r\n"
         << "From: " << from << "\r\n"
         << "Subject: Kode Verifikasi (OTP) - Manajemen Mahasiswa\r\n"
         << "Content-Type: text/plain; charset=UTF-8\r\n"
         << "\r\n"
         << "Halo " << (toName.empty() ? "Mahasiswa" : toName) << ",\r\n\r\n"
         << "Kode verifikasi (OTP) Anda adalah: " << code << "\r\n"
         << "Kode ini berlaku selama 60 detik.\r\n\r\n"
         << "Jika Anda tidak meminta kode ini, abaikan email ini.\r\n";

    UploadCtx ctx{ body.str(), 0 };
    struct curl_slist* recipients = nullptr;
    recipients = curl_slist_append(recipients, to.c_str());

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_USERNAME, user.c_str());
    curl_easy_setopt(curl, CURLOPT_PASSWORD, pass.c_str());
    curl_easy_setopt(curl, CURLOPT_USE_SSL, (long)CURLUSESSL_ALL);
    curl_easy_setopt(curl, CURLOPT_MAIL_FROM, from.c_str());
    curl_easy_setopt(curl, CURLOPT_MAIL_RCPT, recipients);
    curl_easy_setopt(curl, CURLOPT_READFUNCTION, readCb);
    curl_easy_setopt(curl, CURLOPT_READDATA, &ctx);
    curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 20L);

    CURLcode res = curl_easy_perform(curl);
    curl_slist_free_all(recipients);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        std::cerr << "[mailer] SMTP gagal: " << curl_easy_strerror(res) << "\n";
        return false;
    }
    return true;
}
#endif // HAVE_CURL

} // namespace

bool mailer::sendOtp(const std::string& toEmail, const std::string& toName,
                     const std::string& code) {
#ifdef HAVE_CURL
    if (!env("SMTP_URL").empty()) {
        if (sendViaCurl(toEmail, toName, code)) return true;
        // fall through to dev print so the flow still works during demos
    }
#endif
    devPrint(toEmail, code);
    return true;
}
