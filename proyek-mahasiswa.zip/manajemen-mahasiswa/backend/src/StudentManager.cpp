#include "StudentManager.h"
#include "Utils.h"
#include <fstream>
#include <sstream>

// ------------------------- construction / memory -----------------------------

StudentManager::StudentManager(const std::string& filePath)
    : data_(nullptr), count_(0), capacity_(0), filePath_(filePath) {
    ensureCapacity(8);
}

StudentManager::~StudentManager() { freeAll(); }

void StudentManager::freeAll() {
    for (int i = 0; i < count_; ++i) delete data_[i];  // virtual dtor -> clean
    delete[] data_;
    data_ = nullptr;
    count_ = 0;
    capacity_ = 0;
}

void StudentManager::ensureCapacity(int needed) {
    if (needed <= capacity_) return;
    int newCap = capacity_ == 0 ? 8 : capacity_;
    while (newCap < needed) newCap *= 2;          // amortised O(1) growth
    Student** bigger = new Student*[newCap];
    for (int i = 0; i < count_; ++i) bigger[i] = data_[i];
    delete[] data_;                                // free old block (no leak)
    data_ = bigger;
    capacity_ = newCap;
}

// Rule of three: deep copy so two managers never share/double-free pointers.
StudentManager::StudentManager(const StudentManager& other)
    : data_(nullptr), count_(0), capacity_(0), filePath_(other.filePath_) {
    ensureCapacity(other.count_);
    for (int i = 0; i < other.count_; ++i) data_[count_++] = other.data_[i]->clone();
}

StudentManager& StudentManager::operator=(const StudentManager& other) {
    if (this == &other) return *this;
    freeAll();
    filePath_ = other.filePath_;
    ensureCapacity(other.count_ > 0 ? other.count_ : 8);
    for (int i = 0; i < other.count_; ++i) data_[count_++] = other.data_[i]->clone();
    return *this;
}

// ------------------------------- CRUD ----------------------------------------

int StudentManager::indexOfNim(const std::string& nim) const {
    for (int i = 0; i < count_; ++i)
        if (data_[i]->getNim() == nim) return i;
    return -1;
}

bool StudentManager::add(Student* s) {
    if (!s) return false;
    if (indexOfNim(s->getNim()) != -1) { delete s; return false; }  // no dup NIM
    ensureCapacity(count_ + 1);
    data_[count_++] = s;   // ownership transferred
    return true;
}

bool StudentManager::update(const std::string& nim, const std::string& nama,
                            const std::string& email, const std::string& jurusan,
                            int angkatan, const std::string& tipe) {
    int idx = indexOfNim(nim);
    if (idx < 0) return false;

    // If the type changes we must swap the concrete subclass (polymorphism),
    // so rebuild the object rather than mutate in place.
    if (util::toLower(data_[idx]->getTipe()) != util::toLower(tipe)) {
        Student* replacement = makeStudent(tipe, nim, nama, email, jurusan, angkatan);
        if (!replacement) return false;
        delete data_[idx];
        data_[idx] = replacement;
        return true;
    }
    data_[idx]->setNama(nama);
    data_[idx]->setEmail(email);
    data_[idx]->setJurusan(jurusan);
    data_[idx]->setAngkatan(angkatan);
    return true;
}

bool StudentManager::remove(const std::string& nim) {
    int idx = indexOfNim(nim);
    if (idx < 0) return false;
    delete data_[idx];                          // free the object
    for (int i = idx; i < count_ - 1; ++i)      // compact the array
        data_[i] = data_[i + 1];
    --count_;
    return true;
}

void StudentManager::replaceAll(const std::vector<Student*>& items) {
    freeAll();
    ensureCapacity(items.empty() ? 8 : (int)items.size());
    for (Student* s : items) if (s) { if (indexOfNim(s->getNim()) == -1) data_[count_++] = s; else delete s; }
}

// ------------------------------ File I/O -------------------------------------

bool StudentManager::load() {
    std::ifstream in(filePath_);
    if (!in.is_open()) { seedMockData(); save(); return true; }

    // CSV column order: nim,nama,email,jurusan,angkatan,tipe
    std::string line;
    bool first = true;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        if (first) {
            first = false;
            if (util::toLower(line).rfind("nim", 0) == 0) continue;  // skip header
        }
        auto f = util::csvSplit(line);
        if (f.size() < 6) continue;
        int ang = 0;
        try { ang = std::stoi(f[4]); } catch (...) { ang = 0; }
        Student* s = makeStudent(f[5], f[0], f[1], f[2], f[3], ang);
        if (s) add(s);   // add() rejects+frees duplicates safely
    }
    if (count_ == 0) { seedMockData(); save(); }
    return true;
}

bool StudentManager::save() const {
    std::ofstream out(filePath_, std::ios::trunc);
    if (!out.is_open()) return false;
    out << "nim,nama,email,jurusan,angkatan,tipe\n";
    for (int i = 0; i < count_; ++i) out << data_[i]->toCsv() << "\n";
    return true;
}

void StudentManager::seedMockData() {
    // 12 dummy students so the table is populated on first launch.
    struct Row { const char* nim; const char* nama; const char* email;
                 const char* jur; int ang; const char* tipe; };
    static const Row rows[] = {
        {"241011450073","Rifki Ananda","rifki.ananda@unpam.ac.id","Teknik Informatika",2024,"Reguler"},
        {"241011450074","Dewi Lestari","dewi.lestari@unpam.ac.id","Sistem Informasi",2024,"Beasiswa"},
        {"231011450012","Bagas Pratama","bagas.pratama@unpam.ac.id","Teknik Informatika",2023,"Reguler"},
        {"231011450199","Siti Nurhaliza","siti.nur@unpam.ac.id","Sistem Informasi",2023,"Beasiswa"},
        {"221011450441","Arif Wibowo","arif.wibowo@unpam.ac.id","Teknik Informatika",2022,"Reguler"},
        {"241011450088","Putri Maharani","putri.m@unpam.ac.id","Sistem Informasi",2024,"Reguler"},
        {"231011450301","Eko Santoso","eko.santoso@unpam.ac.id","Teknik Informatika",2023,"Beasiswa"},
        {"221011450777","Lina Marlina","lina.marlina@unpam.ac.id","Sistem Informasi",2022,"Reguler"},
        {"241011450215","Fauzan Hakim","fauzan.hakim@unpam.ac.id","Teknik Informatika",2024,"Beasiswa"},
        {"231011450456","Nadia Salsabila","nadia.s@unpam.ac.id","Sistem Informasi",2023,"Reguler"},
        {"221011450123","Yoga Permana","yoga.permana@unpam.ac.id","Teknik Informatika",2022,"Beasiswa"},
        {"241011450330","Citra Ayu","citra.ayu@unpam.ac.id","Sistem Informasi",2024,"Reguler"},
    };
    for (const auto& r : rows)
        add(makeStudent(r.tipe, r.nim, r.nama, r.email, r.jur, r.ang));
}

// --------------------------- serialisation -----------------------------------

std::string StudentManager::toJsonArray(const std::vector<int>* idx) const {
    using util::jsonEscape; using util::htmlEscape;
    auto field = [&](const std::string& v){ return jsonEscape(htmlEscape(v)); };

    std::ostringstream os;
    os << "[";
    int written = 0;
    auto emit = [&](int i){
        Student* s = data_[i];
        if (written++) os << ",";
        os << "{"
           << "\"no\":" << written << ","
           << "\"nim\":\""      << field(s->getNim())     << "\","
           << "\"nama\":\""     << field(s->getNama())    << "\","
           << "\"email\":\""    << field(s->getEmail())   << "\","
           << "\"jurusan\":\""  << field(s->getJurusan()) << "\","
           << "\"angkatan\":"   << s->getAngkatan()       << ","
           << "\"tipe\":\""     << field(s->getTipe())    << "\""
           << "}";
    };
    if (idx) { for (int i : *idx) if (i >= 0 && i < count_) emit(i); }
    else     { for (int i = 0; i < count_; ++i) emit(i); }
    os << "]";
    return os.str();
}

std::string StudentManager::statsJson() const {
    int reguler = 0, beasiswa = 0, ti = 0, si = 0;
    for (int i = 0; i < count_; ++i) {
        if (data_[i]->getTipe() == "Beasiswa") ++beasiswa; else ++reguler;
        if (util::toLower(data_[i]->getJurusan()).find("informatika") != std::string::npos) ++ti;
        else ++si;
    }
    double pReg = count_ ? (100.0 * reguler / count_) : 0.0;
    double pBea = count_ ? (100.0 * beasiswa / count_) : 0.0;
    std::ostringstream os;
    os << "{"
       << "\"total\":"        << count_   << ","
       << "\"reguler\":"      << reguler  << ","
       << "\"beasiswa\":"     << beasiswa << ","
       << "\"informatika\":"  << ti       << ","
       << "\"sisteminfo\":"   << si       << ","
       << "\"pctReguler\":"   << (int)(pReg + 0.5) << ","
       << "\"pctBeasiswa\":"  << (int)(pBea + 0.5)
       << "}";
    return os.str();
}

std::string StudentManager::toCsvBlob() const {
    std::ostringstream os;
    os << "no,nim,nama,email,jurusan,angkatan,tipe\n";
    for (int i = 0; i < count_; ++i) {
        Student* s = data_[i];
        os << (i + 1) << ","
           << util::csvEscape(s->getNim())     << ","
           << util::csvEscape(s->getNama())    << ","
           << util::csvEscape(s->getEmail())   << ","
           << util::csvEscape(s->getJurusan()) << ","
           << s->getAngkatan()                 << ","
           << util::csvEscape(s->getTipe())    << "\n";
    }
    return os.str();
}
