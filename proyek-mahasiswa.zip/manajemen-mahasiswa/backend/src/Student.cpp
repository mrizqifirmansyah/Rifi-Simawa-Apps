#include "Student.h"
#include "Utils.h"
#include <algorithm>

// ---- Base ----
Student::Student(const std::string& nim, const std::string& nama,
                 const std::string& email, const std::string& jurusan,
                 int angkatan)
    : nim_(nim), nama_(nama), email_(email), jurusan_(jurusan), angkatan_(angkatan) {}

Student::~Student() = default;

void Student::setNama(const std::string& v)    { if (!util::trim(v).empty()) nama_ = v; }
void Student::setEmail(const std::string& v)   { if (util::isValidEmail(v)) email_ = v; }
void Student::setJurusan(const std::string& v) { if (!util::trim(v).empty()) jurusan_ = v; }
void Student::setAngkatan(int v)               { if (v >= 1990 && v <= 2100) angkatan_ = v; }

std::string Student::toCsv() const {
    using util::csvEscape;
    return csvEscape(nim_) + "," + csvEscape(nama_) + "," + csvEscape(email_) + "," +
           csvEscape(jurusan_) + "," + std::to_string(angkatan_) + "," + csvEscape(getTipe());
}

// ---- RegularStudent ----
RegularStudent::RegularStudent(const std::string& nim, const std::string& nama,
                               const std::string& email, const std::string& jurusan,
                               int angkatan)
    : Student(nim, nama, email, jurusan, angkatan) {}

std::string RegularStudent::getTipe() const { return "Reguler"; }
Student* RegularStudent::clone() const {
    return new RegularStudent(nim_, nama_, email_, jurusan_, angkatan_);
}

// ---- ScholarshipStudent ----
ScholarshipStudent::ScholarshipStudent(const std::string& nim, const std::string& nama,
                                       const std::string& email, const std::string& jurusan,
                                       int angkatan)
    : Student(nim, nama, email, jurusan, angkatan) {}

std::string ScholarshipStudent::getTipe() const { return "Beasiswa"; }
Student* ScholarshipStudent::clone() const {
    return new ScholarshipStudent(nim_, nama_, email_, jurusan_, angkatan_);
}

// ---- Factory ----
Student* makeStudent(const std::string& tipe, const std::string& nim,
                     const std::string& nama, const std::string& email,
                     const std::string& jurusan, int angkatan) {
    std::string t = util::toLower(util::trim(tipe));
    if (t == "beasiswa" || t == "scholarship")
        return new ScholarshipStudent(nim, nama, email, jurusan, angkatan);
    if (t == "reguler" || t == "regular")
        return new RegularStudent(nim, nama, email, jurusan, angkatan);
    return nullptr;
}
