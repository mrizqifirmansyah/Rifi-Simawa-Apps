#include "Auth.h"
#include "Sha256.h"
#include "Utils.h"
#include <fstream>
#include <sstream>

static const long long OTP_TTL      = 60;            // seconds (1 minute)
static const long long SESSION_TTL  = 60 * 60 * 4;   // 4 hours

Auth::Auth(const std::string& filePath) : filePath_(filePath) { load(); }

void Auth::load() {
    std::ifstream in(filePath_);
    if (!in.is_open()) return;
    // CSV: email,name,passHash,active
    std::string line;
    bool first = true;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        if (first) { first = false; if (util::toLower(line).rfind("email", 0) == 0) continue; }
        auto f = util::csvSplit(line);
        if (f.size() < 4) continue;
        UserRecord u;
        u.email    = f[0];
        u.name     = f[1];
        u.passHash = f[2];
        u.active   = (f[3] == "1" || util::toLower(f[3]) == "true");
        users_[util::toLower(u.email)] = u;
    }
}

void Auth::save() const {
    std::ofstream out(filePath_, std::ios::trunc);
    if (!out.is_open()) return;
    out << "email,name,passHash,active\n";
    for (const auto& kv : users_) {
        const UserRecord& u = kv.second;
        out << util::csvEscape(u.email) << ","
            << util::csvEscape(u.name)  << ","
            << util::csvEscape(u.passHash) << ","
            << (u.active ? "1" : "0") << "\n";
    }
}

Auth::RegResult Auth::registerUser(const std::string& email,
                                   const std::string& name,
                                   const std::string& password) {
    std::string e = util::toLower(util::trim(email));
    std::string n = util::sanitize(name, 80);
    if (!util::isValidEmail(e) || n.empty() || !util::isStrongPassword(password))
        return {Status::BadInput, ""};

    auto it = users_.find(e);
    if (it != users_.end() && it->second.active)
        return {Status::EmailTaken, ""};

    UserRecord u;
    u.email     = e;
    u.name      = n;
    u.passHash  = crypto::hashPassword(password);
    u.active    = false;
    u.otp       = util::randomDigits(6);
    u.otpExpiry = util::nowSeconds() + OTP_TTL;
    users_[e]   = u;
    save();
    return {Status::Ok, u.otp};
}

Auth::RegResult Auth::resendOtp(const std::string& email) {
    std::string e = util::toLower(util::trim(email));
    auto it = users_.find(e);
    if (it == users_.end()) return {Status::NotFound, ""};
    if (it->second.active)  return {Status::AlreadyActive, ""};
    // Always issue a fresh code; never blacklist or lock the email.
    it->second.otp       = util::randomDigits(6);
    it->second.otpExpiry = util::nowSeconds() + OTP_TTL;
    save();
    return {Status::Ok, it->second.otp};
}

Auth::Status Auth::verifyOtp(const std::string& email, const std::string& code) {
    std::string e = util::toLower(util::trim(email));
    auto it = users_.find(e);
    if (it == users_.end()) return Status::NotFound;
    if (it->second.active)  return Status::AlreadyActive;
    if (it->second.otp.empty()) return Status::BadOtp;
    if (util::nowSeconds() > it->second.otpExpiry) return Status::OtpExpired;
    if (util::trim(code) != it->second.otp) return Status::BadOtp;
    it->second.active    = true;
    it->second.otp.clear();
    it->second.otpExpiry = 0;
    save();
    return Status::Ok;
}

Auth::Status Auth::login(const std::string& email, const std::string& password,
                         std::string& tokenOut) {
    std::string e = util::toLower(util::trim(email));
    auto it = users_.find(e);
    if (it == users_.end()) return Status::NotFound;
    if (!it->second.active) return Status::NotActive;
    if (!crypto::verifyPassword(password, it->second.passHash))
        return Status::WrongPassword;

    std::string token = util::randomHex(24);   // 48 hex chars
    sessions_[token] = Session{ e, util::nowSeconds() + SESSION_TTL };
    tokenOut = token;
    return Status::Ok;
}

void Auth::logout(const std::string& token) { sessions_.erase(token); }

std::string Auth::emailForToken(const std::string& token) {
    auto it = sessions_.find(token);
    if (it == sessions_.end()) return "";
    if (util::nowSeconds() > it->second.expiry) { sessions_.erase(it); return ""; }
    return it->second.email;
}

bool Auth::hasUser(const std::string& email) const {
    return users_.find(util::toLower(email)) != users_.end();
}
