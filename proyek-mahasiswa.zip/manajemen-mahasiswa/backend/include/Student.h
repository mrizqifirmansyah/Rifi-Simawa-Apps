#ifndef STUDENT_H
#define STUDENT_H

#include <string>

// =============================================================================
//  Student.h
//  OOP core of the application.
//
//  Demonstrates the four pillars required by the assignment:
//   - Class & Encapsulation : all attributes are private/protected with
//                             validated getters & setters.
//   - Inheritance           : RegularStudent and ScholarshipStudent extend
//                             the abstract base class Student.
//   - Polymorphism          : getTipe()/clone() are virtual and resolved at
//                             runtime through a Student* pointer.
//   - Abstraction           : Student is an abstract base (pure virtual fns).
// =============================================================================

class Student {
protected:
    std::string nim_;       // student ID, e.g. "241011450073"
    std::string nama_;      // full name
    std::string email_;
    std::string jurusan_;   // "Teknik Informatika" / "Sistem Informasi"
    int         angkatan_;  // enrollment year, e.g. 2024

public:
    Student(const std::string& nim,
            const std::string& nama,
            const std::string& email,
            const std::string& jurusan,
            int angkatan);

    // A base class deleted/used through a pointer MUST have a virtual
    // destructor, otherwise `delete basePtr` leaks the derived part.
    virtual ~Student();

    // ---- Encapsulation: getters ----
    const std::string& getNim()      const { return nim_; }
    const std::string& getNama()     const { return nama_; }
    const std::string& getEmail()    const { return email_; }
    const std::string& getJurusan()  const { return jurusan_; }
    int                getAngkatan() const { return angkatan_; }

    // ---- Encapsulation: setters (with light validation) ----
    void setNama(const std::string& v);
    void setEmail(const std::string& v);
    void setJurusan(const std::string& v);
    void setAngkatan(int v);

    // ---- Polymorphism: resolved at runtime ----
    virtual std::string getTipe()  const = 0;  // "Reguler" / "Beasiswa"
    virtual Student*    clone()    const = 0;   // deep copy for safe arrays

    // Serialize one record to a single CSV line (no trailing newline).
    std::string toCsv() const;
};

// -----------------------------------------------------------------------------
//  Derived: a self-funded / regular student.
// -----------------------------------------------------------------------------
class RegularStudent : public Student {
public:
    RegularStudent(const std::string& nim,
                   const std::string& nama,
                   const std::string& email,
                   const std::string& jurusan,
                   int angkatan);

    std::string getTipe() const override;   // returns "Reguler"
    Student*    clone()   const override;
};

// -----------------------------------------------------------------------------
//  Derived: a scholarship student.
// -----------------------------------------------------------------------------
class ScholarshipStudent : public Student {
public:
    ScholarshipStudent(const std::string& nim,
                        const std::string& nama,
                        const std::string& email,
                        const std::string& jurusan,
                        int angkatan);

    std::string getTipe() const override;   // returns "Beasiswa"
    Student*    clone()   const override;
};

// Factory: build the correct subclass from a type string ("Reguler"/"Beasiswa").
// Returns a heap-allocated Student* the caller owns. nullptr on bad type.
Student* makeStudent(const std::string& tipe,
                     const std::string& nim,
                     const std::string& nama,
                     const std::string& email,
                     const std::string& jurusan,
                     int angkatan);

#endif // STUDENT_H
