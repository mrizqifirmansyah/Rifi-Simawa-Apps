#ifndef AUTH_H
#define AUTH_H

#include <string>
#include <unordered_map>
#include <vector>

// =============================================================================
//  Auth.h
//  Account lifecycle + session management.
//   register -> account created "pending", OTP emailed
//   verify   -> correct, non-expired OTP flips account to "active"
//   login    -> only active accounts; issues a session token
//
//  OTP policy (per spec):
//   - code expires 60 seconds after it is issued
//   - user may "resend" any time; we re-issue a fresh code and NEVER blacklist
//     the email or rate-lock it out.
//
//  Passwords are stored only as salted SHA-256 hashes. Users persist to CSV.
// =============================================================================

struct UserRecord {
    std::string email;
    std::string name;
    std::string passHash;     // "salt$hash"
    bool        active = false;
    std::string otp;          // current one-time code ("" once consumed)
    long long   otpExpiry = 0;// unix seconds; 0 means none pending
};

struct Session {
    std::string email;
    long long   expiry;       // unix seconds
};

class Auth {
private:
    std::string filePath_;
    std::unordered_map<std::string, UserRecord> users_;   // key = email(lower)
    std::unordered_map<std::string, Session>    sessions_;// key = token

    void load();
    void save() const;

public:
    explicit Auth(const std::string& filePath);

    enum class Status { Ok, BadInput, EmailTaken, NotFound, WrongPassword,
                        NotActive, BadOtp, OtpExpired, AlreadyActive };

    // Returns {status, otpCode}. Caller emails otpCode on Ok.
    struct RegResult { Status status; std::string otp; };
    RegResult registerUser(const std::string& email,
                           const std::string& name,
                           const std::string& password);

    // Re-issue a fresh OTP (1-minute validity). Never blacklists.
    RegResult resendOtp(const std::string& email);

    Status verifyOtp(const std::string& email, const std::string& code);

    // On success returns Ok and fills `tokenOut` with a new session id.
    Status login(const std::string& email, const std::string& password,
                 std::string& tokenOut);

    void   logout(const std::string& token);

    // Validate a session token; returns email on success, "" otherwise.
    std::string emailForToken(const std::string& token);

    // For seeding a demo login in dev.
    bool hasUser(const std::string& email) const;
};

#endif // AUTH_H
