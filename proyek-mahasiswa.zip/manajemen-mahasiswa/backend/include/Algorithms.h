#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include "Student.h"
#include <string>
#include <vector>

// =============================================================================
//  Algorithms.h
//  Pure search & sort implementations operating on raw dynamic arrays of
//  Student* (Student**). Every function carries its Big-O analysis.
//
//  Searching: Linear, Sequential (sentinel), Binary.
//  Sorting  : Insertion, Selection, Bubble, Merge, Shell.
//
//  Sort/search keys are selected by SortKey. Comparison is case-insensitive
//  for text keys to behave well in a UI.
// =============================================================================

namespace algo {

enum class SortKey { Nama, Nim, Jurusan };

// Extract the comparison key of a student for a given SortKey (lowercased).
std::string keyOf(const Student* s, SortKey key);

// ---- SEARCHING ---------------------------------------------------------------
// All three return indices (into the array) of every record whose chosen field
// contains `query` (case-insensitive). They differ in algorithm, as required.

// Linear search   -> Time: O(n)   Space: O(1)
std::vector<int> linearSearch(Student** arr, int n,
                              const std::string& query, SortKey field);

// Sequential search with sentinel -> Time: O(n)  Space: O(1)
// Same asymptotic cost as linear but avoids a bounds-check each iteration.
std::vector<int> sequentialSearch(Student** arr, int n,
                                  const std::string& query, SortKey field);

// Binary search   -> Time: O(log n) per probe  Space: O(1)
// Requires the array to be SORTED on `field` first; the caller (or this fn)
// sorts a copy. Matches by prefix on the chosen key.
std::vector<int> binarySearch(Student** arr, int n,
                              const std::string& query, SortKey field);

// ---- SORTING -----------------------------------------------------------------
// All sorts are stable-enough for UI use and sort the array IN PLACE by `key`,
// ascending. They swap Student* pointers, never copy objects (cheap + leak-free).

// Insertion sort  -> Best O(n)  Avg/Worst O(n^2)  Space O(1)  (stable)
void insertionSort(Student** arr, int n, SortKey key);

// Selection sort  -> O(n^2) all cases  Space O(1)  (not stable)
void selectionSort(Student** arr, int n, SortKey key);

// Bubble sort     -> Best O(n)  Avg/Worst O(n^2)  Space O(1)  (stable)
void bubbleSort(Student** arr, int n, SortKey key);

// Merge sort      -> O(n log n) all cases  Space O(n)  (stable)
void mergeSort(Student** arr, int n, SortKey key);

// Shell sort      -> ~O(n log^2 n) avg (gap-dependent)  Space O(1)  (not stable)
void shellSort(Student** arr, int n, SortKey key);

// Dispatch helpers used by the API layer (string -> algorithm).
void   sortBy(Student** arr, int n, const std::string& algoName, SortKey key);
SortKey parseKey(const std::string& s);  // "nama"/"nim"/"jurusan"

} // namespace algo

#endif // ALGORITHMS_H
