#ifndef STUDENT_MANAGER_H
#define STUDENT_MANAGER_H

#include "Student.h"
#include "Algorithms.h"
#include <string>
#include <vector>

// =============================================================================
//  StudentManager.h
//  Owns a hand-rolled DYNAMIC ARRAY of Student* (Student**) with manual growth.
//  This satisfies the "pointers + dynamic array, zero memory leaks" rule:
//   - storage grows by doubling (amortised O(1) append)
//   - every Student* is deleted in the destructor / on clear()
//   - rule of three is honoured (copy ctor + copy assignment deep-copy)
//
//  Persistence: CSV file. On first run with no/empty file it auto-generates
//  10-15 dummy students so the UI is populated immediately.
// =============================================================================

class StudentManager {
private:
    Student**   data_;       // dynamic array of owning pointers
    int         count_;      // number of live elements
    int         capacity_;   // allocated slots
    std::string filePath_;

    void ensureCapacity(int needed);  // grow if required
    void freeAll();                   // delete every element + the array

public:
    explicit StudentManager(const std::string& filePath);
    ~StudentManager();

    // Rule of three (we manage raw memory, so deep-copy is mandatory).
    StudentManager(const StudentManager& other);
    StudentManager& operator=(const StudentManager& other);

    int count() const { return count_; }

    // ---- CRUD ----
    // add() takes ownership of `s` (a heap Student*). Rejects duplicate NIM.
    bool add(Student* s);
    bool update(const std::string& nim,
                const std::string& nama,
                const std::string& email,
                const std::string& jurusan,
                int angkatan,
                const std::string& tipe);
    bool remove(const std::string& nim);
    int  indexOfNim(const std::string& nim) const;  // -1 if not found

    // Read-only access for the API layer.
    Student*  at(int i) const { return (i >= 0 && i < count_) ? data_[i] : nullptr; }
    Student** raw()     const { return data_; }

    // ---- File I/O ----
    bool load();   // read CSV; if missing/empty -> seedMockData()
    bool save() const;
    void seedMockData();

    // Replace whole dataset (used by JSON import). Takes ownership of items.
    void replaceAll(const std::vector<Student*>& items);

    // ---- Serialisation for the API ----
    // Build a JSON array string of all students, optionally filtered to the
    // index list `idx` (used after a search). Applies HTML-escaping per field.
    std::string toJsonArray(const std::vector<int>* idx = nullptr) const;

    // Dashboard stats as a JSON object string.
    std::string statsJson() const;

    // CSV dump of all students (with header) for the Export feature.
    std::string toCsvBlob() const;
};

#endif // STUDENT_MANAGER_H
