#ifndef MAILER_H
#define MAILER_H

#include <string>

// =============================================================================
//  Mailer.h
//  Sends the OTP email. Configuration is read from environment variables so no
//  secret is ever hard-coded:
//
//    SMTP_URL   e.g. smtps://smtp.gmail.com:465
//    SMTP_USER  e.g. youraccount@gmail.com
//    SMTP_PASS  app password (NOT your normal password)
//    SMTP_FROM  defaults to SMTP_USER
//
//  If SMTP_URL is empty OR libcurl is not available at build time, the mailer
//  falls back to printing the OTP to the server console (dev mode) so the app
//  remains testable without a mail server.
// =============================================================================

namespace mailer {

// Returns true if the message was handed off (sent or dev-printed).
bool sendOtp(const std::string& toEmail,
             const std::string& toName,
             const std::string& code);

} // namespace mailer

#endif // MAILER_H
