#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <vector>

// =============================================================================
//  Utils.h
//  Defensive helpers: input sanitisation (anti XSS / injection), validation,
//  and small CSV/JSON-safe encoders. The backend never trusts client input.
// =============================================================================

namespace util {

// Trim leading/trailing whitespace.
std::string trim(const std::string& s);

// Lowercase copy (ASCII).
std::string toLower(const std::string& s);

// ----- SANITISATION -----------------------------------------------------------
// Strip control chars and characters used for command/SQL injection
// (`; | & $ ` \n \r \0` and angle brackets) before the value is ever stored.
// We DO NOT silently mangle legitimate names; we remove only dangerous bytes.
std::string sanitize(const std::string& raw, size_t maxLen = 255);

// Encode a string for safe HTML output (defence-in-depth against stored XSS).
// & < > " ' are turned into entities.
std::string htmlEscape(const std::string& s);

// ----- VALIDATION -------------------------------------------------------------
bool isValidEmail(const std::string& s);

// Strong password rule: >= 8 chars, at least one upper, one lower,
// one digit and one symbol. Same rule the frontend enforces live.
bool isStrongPassword(const std::string& s);

// NIM must be 8-15 digits only.
bool isValidNim(const std::string& s);

// ----- CSV --------------------------------------------------------------------
// Quote a field if it contains comma, quote or newline; double internal quotes.
std::string csvEscape(const std::string& field);

// Split a single CSV line into fields, honouring quotes.
// (Simple RFC-4180-ish parser, good enough for our own files.)
std::vector<std::string> csvSplit(const std::string& line);

// ----- JSON -------------------------------------------------------------------
// Escape a string so it can be embedded inside a JSON string literal.
std::string jsonEscape(const std::string& s);

// ----- MISC -------------------------------------------------------------------
// Cryptographically-seeded random numeric string of n digits (for OTP).
std::string randomDigits(int n);

// Random hex token of n bytes (for session ids), e.g. 32 hex chars for n=16.
std::string randomHex(int nBytes);

// Current unix time in seconds.
long long nowSeconds();

} // namespace util

#endif // UTILS_H
