#ifndef SHA256_H
#define SHA256_H

#include <string>

// =============================================================================
//  Sha256.h
//  Self-contained SHA-256 (FIPS 180-4). No external crypto dependency so the
//  project compiles anywhere. Used for salted password hashing.
// =============================================================================

namespace crypto {

// Returns the lowercase hex digest (64 chars) of the input.
std::string sha256(const std::string& input);

// Produce a "salt$hash" string. salt is random hex; hash = sha256(salt + pw),
// stretched over several rounds to slow brute-force.
std::string hashPassword(const std::string& password);

// Verify a plaintext password against a stored "salt$hash" string.
bool verifyPassword(const std::string& password, const std::string& stored);

} // namespace crypto

#endif // SHA256_H
