/* auth.js — authentication flow, live validation, OTP timer, GSAP + toasts */
(() => {
  "use strict";

  // ---------- tiny helpers ----------
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      ...opts,
    });
    let data = {};
    try { data = await res.json(); } catch (_) {}
    return { ok: res.ok, status: res.status, data };
  }

  // ---------- toast system (GSAP slide-in with custom easing) ----------
  function toast(type, title, msg) {
    const wrap = $("#toasts");
    const el = document.createElement("div");
    el.className = `toast toast--${type}`;
    const icon = type === "success" ? "✓" : type === "error" ? "!" : "i";
    el.innerHTML = `<span class="icon">${icon}</span>
                    <span class="body"><b>${title}</b>${msg}</span>`;
    wrap.appendChild(el);
    gsap.fromTo(el, { x: 420, rotate: 1.5, opacity: 0 },
      { x: 0, rotate: 0, opacity: 1, duration: 0.55, ease: "back.out(1.7)" });
    setTimeout(() => {
      gsap.to(el, { x: 440, opacity: 0, duration: 0.4, ease: "power3.in",
        onComplete: () => el.remove() });
    }, 3800);
  }

  // ---------- tabs ----------
  function showPane(name) {
    $$(".pane").forEach(p => p.classList.remove("active"));
    $(`#pane-${name}`).classList.add("active");
    const pane = $(`#pane-${name}`);
    gsap.fromTo(pane.children,
      { y: 14, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.4, stagger: 0.05, ease: "power2.out" });
  }
  $$("#tabs button").forEach(b => b.addEventListener("click", () => {
    $$("#tabs button").forEach(x => x.classList.remove("active"));
    b.classList.add("active");
    showPane(b.dataset.tab);
  }));

  // ---------- live password validation ----------
  const pwRules = {
    len:    v => v.length >= 8,
    upper:  v => /[A-Z]/.test(v),
    lower:  v => /[a-z]/.test(v),
    digit:  v => /[0-9]/.test(v),
    symbol: v => /[^A-Za-z0-9]/.test(v),
  };
  function checkPassword() {
    const v = $("#r-pass").value;
    let allMet = true;
    $$("#pw-rules li").forEach(li => {
      const met = pwRules[li.dataset.rule](v);
      li.classList.toggle("met", met);
      if (!met) allMet = false;
    });
    return allMet;
  }
  function checkEmail() {
    const v = $("#r-email").value.trim();
    const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
    const hint = $("#r-email-hint");
    hint.textContent = v === "" ? "" : (ok ? "Email valid" : "Format email belum benar");
    hint.className = "hint " + (v === "" ? "" : ok ? "ok" : "bad");
    return ok;
  }
  function refreshRegisterBtn() {
    const ready = checkPassword() && checkEmail() && $("#r-name").value.trim().length > 0;
    $("#btn-register").disabled = !ready;
  }
  ["#r-pass", "#r-email", "#r-name"].forEach(s =>
    $(s).addEventListener("input", refreshRegisterBtn));

  // ---------- register ----------
  $("#btn-register").addEventListener("click", async () => {
    const payload = {
      name: $("#r-name").value.trim(),
      email: $("#r-email").value.trim(),
      password: $("#r-pass").value,
    };
    const btn = $("#btn-register"); btn.disabled = true;
    const { ok, data } = await api("/api/register", { method: "POST", body: JSON.stringify(payload) });
    btn.disabled = false;
    if (ok) {
      pendingEmail = payload.email;
      $("#otp-email").textContent = pendingEmail;
      toast("success", "OTP Terkirim", data.message);
      goOtp();
    } else {
      toast("error", "Gagal Daftar", data.message || "Terjadi kesalahan.");
    }
  });

  // ---------- OTP flow ----------
  let pendingEmail = "";
  let otpTimer = null;

  function startOtpCountdown(seconds = 60) {
    clearInterval(otpTimer);
    let left = seconds;
    const b = $("#otp-timer b");
    const resend = $("#btn-resend");
    $("#btn-verify").disabled = false;
    b.textContent = left;
    otpTimer = setInterval(() => {
      left--;
      b.textContent = Math.max(left, 0);
      if (left <= 0) {
        clearInterval(otpTimer);
        $("#otp-timer").innerHTML = "Kode <b>kedaluwarsa</b> — silakan kirim ulang.";
        $("#btn-verify").disabled = true;
      }
    }, 1000);
    void resend; // resend always allowed (no blacklist)
  }

  function goOtp() {
    $$("#tabs button").forEach(x => x.classList.remove("active"));
    showPane("otp");
    $$("#otp-inputs input").forEach(i => (i.value = ""));
    $$("#otp-inputs input")[0].focus();
    startOtpCountdown(60);
  }

  // auto-advance + paste support for OTP boxes
  const otpBoxes = $$("#otp-inputs input");
  otpBoxes.forEach((box, i) => {
    box.addEventListener("input", () => {
      box.value = box.value.replace(/\D/g, "").slice(0, 1);
      if (box.value && i < otpBoxes.length - 1) otpBoxes[i + 1].focus();
    });
    box.addEventListener("keydown", e => {
      if (e.key === "Backspace" && !box.value && i > 0) otpBoxes[i - 1].focus();
    });
    box.addEventListener("paste", e => {
      const txt = (e.clipboardData.getData("text") || "").replace(/\D/g, "").slice(0, 6);
      if (!txt) return;
      e.preventDefault();
      txt.split("").forEach((c, k) => { if (otpBoxes[k]) otpBoxes[k].value = c; });
      otpBoxes[Math.min(txt.length, 5)].focus();
    });
  });
  const readOtp = () => otpBoxes.map(b => b.value).join("");

  $("#btn-verify").addEventListener("click", async () => {
    const otp = readOtp();
    if (otp.length !== 6) return toast("error", "Kode Kurang", "Masukkan 6 digit kode.");
    const { ok, data } = await api("/api/verify", {
      method: "POST", body: JSON.stringify({ email: pendingEmail, otp }),
    });
    if (ok) {
      toast("success", "Terverifikasi", "Akun aktif. Silakan login.");
      clearInterval(otpTimer);
      $("#l-email").value = pendingEmail;
      $$("#tabs button")[0].classList.add("active");
      showPane("login");
    } else {
      toast("error", "Verifikasi Gagal", data.message || "Kode salah.");
    }
  });

  $("#btn-resend").addEventListener("click", async () => {
    const { ok, data } = await api("/api/resend-otp", {
      method: "POST", body: JSON.stringify({ email: pendingEmail }),
    });
    if (ok) { toast("info", "Kode Baru", data.message); $("#otp-timer").innerHTML = 'Kode kedaluwarsa dalam <b>60</b> detik'; startOtpCountdown(60); }
    else toast("error", "Gagal", data.message || "Tidak bisa mengirim ulang.");
  });

  // ---------- login ----------
  async function doLogin() {
    const payload = { email: $("#l-email").value.trim(), password: $("#l-pass").value };
    if (!payload.email || !payload.password) return toast("error", "Lengkapi", "Email & password wajib diisi.");
    const btn = $("#btn-login"); btn.disabled = true;
    const { ok, data } = await api("/api/login", { method: "POST", body: JSON.stringify(payload) });
    btn.disabled = false;
    if (ok) {
      toast("success", "Berhasil", "Mengalihkan ke dashboard…");
      setTimeout(() => (window.location.href = "/dashboard"), 600);
    } else {
      toast("error", "Login Gagal", data.message || "Email atau password salah.");
    }
  }
  $("#btn-login").addEventListener("click", doLogin);
  $("#l-pass").addEventListener("keydown", e => { if (e.key === "Enter") doLogin(); });

  // ---------- entrance animation ----------
  gsap.from("#card", { y: 26, opacity: 0, duration: 0.6, ease: "power3.out" });
})();
